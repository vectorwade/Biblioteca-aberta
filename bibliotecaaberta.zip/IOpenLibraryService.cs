using LibraryApi.Models;

namespace LibraryApi.Services
{
    public interface IOpenLibraryService
    {
        Task<SearchResult?> SearchAsync(string query, int page = 1);
        Task<BookData?> GetBookByOLIDAsync(string olid);
        string GetCoverUrlByOlid(string olid, string size = "M");
        Task<string?> GetAuthorDetailsAsync(string authorKey);
    }
}
