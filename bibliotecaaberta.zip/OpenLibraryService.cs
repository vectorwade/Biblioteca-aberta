using System.Net.Http.Json;
using System.Text.Json;
using LibraryApi.Models;

namespace LibraryApi.Services
{
    public class OpenLibraryService : IOpenLibraryService
    {
        private readonly HttpClient _http;
        private readonly JsonSerializerOptions _jsonOptions = new() { PropertyNameCaseInsensitive = true };

        public OpenLibraryService(HttpClient http)
        {
            _http = http;
        }

        public async Task<SearchResult?> SearchAsync(string query, int page = 1)
        {
            var url = $"search.json?q={Uri.EscapeDataString(query)}&page={page}";
            var res = await _http.GetStreamAsync(url);
            return await JsonSerializer.DeserializeAsync<SearchResult>(res, _jsonOptions);
        }

        public async Task<BookData?> GetBookByOLIDAsync(string olid)
        {
            // Use the Books API
            var url = $"api/books?bibkeys=OLID:{Uri.EscapeDataString(olid)}&format=json&jscmd=data";
            var stream = await _http.GetStreamAsync(url);
            var doc = await JsonSerializer.DeserializeAsync<Dictionary<string, BookData>>(stream, _jsonOptions);
            if (doc != null && doc.TryGetValue($"OLID:{olid}", out var data)) return data;
            return null;
        }

        public string GetCoverUrlByOlid(string olid, string size = "M")
        {
            // sizes: S, M, L
            return $"https://covers.openlibrary.org/b/olid/{Uri.EscapeDataString(olid)}-{size}.jpg";
        }

        public async Task<string?> GetAuthorDetailsAsync(string authorKey)
        {
            // authorKey expected like "/authors/OL1A" or "OL1A"
            var cleaned = authorKey?.Replace("/authors/", "");
            if (string.IsNullOrEmpty(cleaned)) return null;
            var url = $"authors/{cleaned}.json";
            try
            {
                return await _http.GetStringAsync(url);
            }
            catch
            {
                return null;
            }
        }
    }
}
