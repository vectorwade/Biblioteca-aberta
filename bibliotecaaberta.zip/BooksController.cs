using LibraryApi.Data;
using LibraryApi.Models;
using LibraryApi.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace LibraryApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class BooksController : ControllerBase
    {
        private readonly IOpenLibraryService _open;
        private readonly AppDbContext _db;

        public BooksController(IOpenLibraryService open, AppDbContext db)
        {
            _open = open;
            _db = db;
        }

        // GET api/books/search?q=harry
        [HttpGet("search")]
        public async Task<IActionResult> Search([FromQuery] string q, [FromQuery] int page = 1)
        {
            if (string.IsNullOrWhiteSpace(q)) return BadRequest("q required");
            var res = await _open.SearchAsync(q, page);
            return Ok(res);
        }

        // GET api/books/olid/OL123M
        [HttpGet("olid/{olid}")]
        public async Task<IActionResult> GetByOlid(string olid)
        {
            var data = await _open.GetBookByOLIDAsync(olid);
            if (data == null) return NotFound();
            return Ok(data);
        }

        // GET api/books/cover/OL123M?size=L
        [HttpGet("cover/{olid}")]
        public IActionResult Cover(string olid, [FromQuery] string size = "M")
        {
            var url = _open.GetCoverUrlByOlid(olid, size);
            return Redirect(url);
        }

        // Local library: add a book to local collection
        [HttpPost("local")]
        public async Task<IActionResult> AddLocal([FromBody] LocalBook book)
        {
            _db.LocalBooks.Add(book);
            await _db.SaveChangesAsync();
            return CreatedAtAction(nameof(GetLocal), new { id = book.Id }, book);
        }

        [HttpGet("local/{id}")]
        public async Task<IActionResult> GetLocal(int id)
        {
            var b = await _db.LocalBooks.FindAsync(id);
            if (b == null) return NotFound();
            return Ok(b);
        }

        [HttpGet("local")]
        public async Task<IActionResult> ListLocal()
        {
            var list = await _db.LocalBooks.ToListAsync();
            return Ok(list);
        }

        // Lend a local book
        [HttpPost("local/{id}/lend")]
        public async Task<IActionResult> LendLocal(int id, [FromBody] string borrower)
        {
            var book = await _db.LocalBooks.FindAsync(id);
            if (book == null) return NotFound();
            if (!book.IsAvailable) return BadRequest("Book not available");
            book.IsAvailable = false;
            var loan = new BookLoan { LocalBookId = id, Borrower = borrower };
            _db.BookLoans.Add(loan);
            await _db.SaveChangesAsync();
            return Ok(loan);
        }

        [HttpPost("local/{id}/return")]
        public async Task<IActionResult> ReturnLocal(int id)
        {
            var book = await _db.LocalBooks.FindAsync(id);
            if (book == null) return NotFound();
            var loan = await _db.BookLoans.Where(l => l.LocalBookId == id && l.ReturnDate == null).OrderByDescending(l => l.LoanDate).FirstOrDefaultAsync();
            if (loan == null) return BadRequest("No active loan");
            loan.ReturnDate = DateTime.UtcNow;
            book.IsAvailable = true;
            await _db.SaveChangesAsync();
            return Ok(loan);
        }
    }
}
